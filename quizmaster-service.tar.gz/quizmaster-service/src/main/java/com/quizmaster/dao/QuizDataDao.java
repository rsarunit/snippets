package com.quizmaster.dao;

import java.util.List;

import com.quizmaster.model.Answer;
import com.quizmaster.model.QuizForm;
import com.quizmaster.model.QuizQuestion;
import com.quizmaster.model.QuizResponse;

public interface QuizDataDao {

	public boolean saveQuizForm(QuizForm quizForm);
	public boolean saveQuizResult(QuizResponse quizResponse);
	
	
	public QuizForm getQuizForm(String quizType);
	
	
	public boolean saveQuestion(QuizQuestion q);
	public List<QuizQuestion> getQuestionsForType(String quizType);
	
	public boolean saveAllQuestion(List<QuizQuestion> questions);
	
	public QuizResponse validateAnswer(List<Answer> answers);
	public boolean validateAnswer(Answer ans);
	
	public long quizResultCount(String quizType);
	public List<QuizResponse> getAllResults();
	
	public boolean dropCollection();
}
