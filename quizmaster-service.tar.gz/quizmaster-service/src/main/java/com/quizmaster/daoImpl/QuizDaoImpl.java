package com.quizmaster.daoImpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.quizmaster.dao.QuizDataDao;
import com.quizmaster.model.Answer;
import com.quizmaster.model.Question;
import com.quizmaster.model.QuizForm;
import com.quizmaster.model.QuizQuestion;
import com.quizmaster.model.QuizResponse;

@Repository
@Qualifier("quizDataDao")
public class QuizDaoImpl implements QuizDataDao {

	@Autowired
	MongoTemplate mongoTemplate;
	
	@Override
	public QuizForm getQuizForm(String quizType) {
		Query query=new Query();
		query.addCriteria(Criteria.where("formName").is(quizType));
		return mongoTemplate.findOne(query, QuizForm.class);
	}
	
	

	@Override
	public boolean saveQuizForm(QuizForm quizForm) {
		mongoTemplate.save(quizForm);
		return true;
	}

	@Override
	public boolean saveQuestion(QuizQuestion q) {
		mongoTemplate.save(q);
		return true;
	}

	@Override
	public List<QuizQuestion> getQuestionsForType(String quizType) {
		Query query=new Query();
		query.addCriteria(Criteria.where("quizType").is(quizType));
		query.fields().include("quizType");
		query.fields().include("qid");
		query.fields().include("question");
		query.fields().include("a");
		query.fields().include("b");
		query.fields().include("c");
		query.fields().include("d");
		return mongoTemplate.find(query, QuizQuestion.class);
	}

	@Override
	public boolean saveAllQuestion(List<QuizQuestion> questions) {
		mongoTemplate.insertAll(questions);
		return true;
	}



	@Override
	public QuizResponse validateAnswer(List<Answer> answers) {
		List<String> list=new ArrayList<String>();
		for(Answer ans:answers){
			list.add(ans.getQid());
		}
		Query query=new Query();
		query.addCriteria(Criteria.where("qid").in(list));
		query.fields().include("qid");
		query.fields().include("answer");
		//List<QuizQuestion> questions=mongoTemplate.find(query, QuizQuestion.class);
		return null;
	}



	@Override
	public boolean validateAnswer(Answer ans) {
		Query query=new Query();
		query.addCriteria(Criteria.where("qid").is(ans.getQid()));
		query.addCriteria(Criteria.where("answer").is(ans.getAnswer()));
		QuizQuestion Qu = mongoTemplate.findOne(query, QuizQuestion.class);
		if(Qu==null){
			return false;
		}else{
			return true;
		}
	}



	@Override
	public long quizResultCount(String quizType) {
		Query query=new Query();
		query.addCriteria(Criteria.where("quizType").is(quizType));
		return mongoTemplate.count(query, QuizResponse.class);
	}



	@Override
	public boolean saveQuizResult(QuizResponse quizResponse) {
		mongoTemplate.save(quizResponse);
		return true;
	}



	@Override
	public List<QuizResponse> getAllResults() {
		Query query=new Query();
		query.with(new Sort(Sort.Direction.DESC, "playedOn"));
		return mongoTemplate.find(query,QuizResponse.class);
	}



	@Override
	public boolean dropCollection() {
		mongoTemplate.dropCollection(Question.class);
		return true;
	}
	
	

	

}
