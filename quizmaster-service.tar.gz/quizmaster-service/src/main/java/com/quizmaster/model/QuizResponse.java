package com.quizmaster.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class QuizResponse {

	@Id
	private String id;
	private String username;
	private String quizType;
	private int score;
	private long playedOn;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getQuizType() {
		return quizType;
	}
	public void setQuizType(String quizType) {
		this.quizType = quizType;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public long getPlayedOn() {
		return playedOn;
	}
	public void setPlayedOn(long playedOn) {
		this.playedOn = playedOn;
	}
}
