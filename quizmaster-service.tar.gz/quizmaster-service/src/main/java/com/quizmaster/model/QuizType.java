package com.quizmaster.model;

public enum QuizType {

	GenralKnowledge,ComputerQuiz,CapitalQuiz,DatabaseQuiz
}
