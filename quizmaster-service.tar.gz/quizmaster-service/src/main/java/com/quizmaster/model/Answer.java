package com.quizmaster.model;

public class Answer {

	private String qid;
	private String answer;
	public String getQid() {
		return qid;
	}
	public void setQid(String qid) {
		this.qid = qid;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	@Override
	public String toString() {
		return "Answer [qid=" + qid + ", answer=" + answer + "]";
	}
}
