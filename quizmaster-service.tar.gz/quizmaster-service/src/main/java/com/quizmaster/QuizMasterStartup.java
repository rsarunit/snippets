package com.quizmaster;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import com.quizmaster.dao.QuizDataDao;
import com.quizmaster.model.QuizQuestion;
import com.quizmaster.util.CSVFileReader;

@Component
public class QuizMasterStartup implements ApplicationListener<ApplicationReadyEvent> {

	@Autowired
	QuizDataDao quizDataDao;
	
	@Autowired
	CSVFileReader csvFileReader;
	
	@Value("${quiz.loadQuestion}")
	private boolean loadQuestion ;
	
	@Override
	public void onApplicationEvent(ApplicationReadyEvent event) {
		if(loadQuestion){
	    quizDataDao.dropCollection();
		List<QuizQuestion> quizQuestions = csvFileReader.getQuizQuestions();
		quizDataDao.saveAllQuestion(quizQuestions);
		}
	}

}
