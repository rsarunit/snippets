package com.quizmaster.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.quizmaster.dao.QuizDataDao;
import com.quizmaster.model.Answer;
import com.quizmaster.model.AnswerForm;
import com.quizmaster.model.QuizQuestion;
import com.quizmaster.model.QuizResponse;

@RestController
@CrossOrigin
@RequestMapping("/quiz")
public class QuizDataController {

	@Autowired
	QuizDataDao quizDataDao;
	
	@RequestMapping(value="/{type}",method=RequestMethod.GET)
	public List<QuizQuestion> getQuizData(@PathVariable(value="type") String type){
		return quizDataDao.getQuestionsForType(type);
	}
	
	@RequestMapping(value="/validate",method=RequestMethod.POST)
	public QuizResponse validateAnswers(@RequestBody AnswerForm answers){
		int quizScore=0;
		for(Answer ans:answers.getAnswers()){
			if(quizDataDao.validateAnswer(ans)){
				quizScore=quizScore+1;
			}
		}
		QuizResponse qu=new QuizResponse();
		qu.setPlayedOn(System.currentTimeMillis());
		qu.setQuizType(answers.getQuizType());
		qu.setScore(quizScore);
		qu.setUsername(answers.getUsername());
		quizDataDao.saveQuizResult(qu);
		return qu;
	}
	
	@RequestMapping(value="/getScoreBoard",method=RequestMethod.GET)
	public List<QuizResponse> getScoreBoard(){
		return quizDataDao.getAllResults();
	}
	
	@RequestMapping(value="/getQuizPlayCount/{type}",method=RequestMethod.GET)
	public QuizResponse getQuizPlayCount(@PathVariable(value="type") String type){
		long count=quizDataDao.quizResultCount(type);
		QuizResponse quizR=new QuizResponse();
		quizR.setScore(Math.toIntExact(count));
		return quizR;
	}
	
	
	
	
	
}
