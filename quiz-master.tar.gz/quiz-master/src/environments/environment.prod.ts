export const environment = {
  production: true,
  serverUrl:""
};
