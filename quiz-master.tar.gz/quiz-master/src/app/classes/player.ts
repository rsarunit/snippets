export class Player{
    name:string;
    mailId:string;
}