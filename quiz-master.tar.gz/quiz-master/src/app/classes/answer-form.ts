import {Answer} from './answer';
export class AnswerForm{
    username:string;
    quizType:string;
    answers:Answer[];
}