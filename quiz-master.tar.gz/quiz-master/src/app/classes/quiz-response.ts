export class QuizResponse{
    username:string;
    score:number;
    quizType:string;
    playedOn:string;
    id:string;
}