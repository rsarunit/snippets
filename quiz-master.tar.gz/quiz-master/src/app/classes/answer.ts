export class Answer{
    qid:string;
    answer:string;
}