import {Question} from './question';
export class QuizForm{
    formName:string;
    questions:Question[]=[];
}