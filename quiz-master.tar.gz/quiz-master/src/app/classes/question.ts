export class Question{
    quizType:string;
	qid:string;
	question:string;
	a:string;
	b:string;
	c:string;
    d:string;
    answer:string="";
}