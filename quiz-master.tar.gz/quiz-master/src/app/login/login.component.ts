import { Component, OnInit,ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import {Router} from '@angular/router';
@Component({
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  @ViewChild('loginForm')
  private loginForm: NgForm;

  constructor(private router:Router) { }

  
  ngOnInit() {
    localStorage.removeItem('username');
  }

  register(myForm: NgForm) {
    console.log(myForm.value);
    if(myForm.value.email==''){
      return;
    }else{
      localStorage.setItem('username',myForm.value.email);
      this.router.navigate(['/dashboard']);
    }
    
    console.log('Registration successful.');
  }

}
