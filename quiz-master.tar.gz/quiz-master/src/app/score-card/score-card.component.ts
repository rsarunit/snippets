import { Component, OnInit } from '@angular/core';
import {RestService} from '../rest.service';
import {QuizResponse} from '../classes/quiz-response';
@Component({
  selector: 'app-score-card',
  templateUrl: './score-card.component.html',
  styleUrls: ['./score-card.component.css']
})
export class ScoreCardComponent implements OnInit {

  constructor(private rest:RestService) { }

  scoreDetails:QuizResponse[]=[];

  ngOnInit() {
    this.rest.getScoreCardDetails().subscribe(res=>{
      this.scoreDetails=res;
    });
  }

}
