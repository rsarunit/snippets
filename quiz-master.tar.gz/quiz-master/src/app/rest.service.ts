import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {environment} from '../environments/environment';
import {Question} from './classes/question';
import {AnswerForm} from './classes/answer-form';
import {QuizResponse} from './classes/quiz-response';
import {Observable} from 'rxjs';
@Injectable()
export class RestService {

  url:string=environment.serverUrl;
  constructor(private http:HttpClient) { }

  getQuizFormData(quizType:string){
    return this.http.get<Question[]>(this.url+'quiz/'+quizType);
  }


  validateAnswer(answer:AnswerForm){
    return this.http.post<QuizResponse>(this.url+'quiz/validate',answer);
  }
  test(){
    return this.http.get(this.url+'test');
  }

  getPlayerName(){
    return Observable.of(localStorage.getItem('username'));
  }

  getScoreCardDetails(){
    return this.http.get<QuizResponse[]>(this.url+"quiz/getScoreBoard");
  }

  getQuizPlayedCount(quizType:string){
    return this.http.get<QuizResponse>(this.url+"quiz//getQuizPlayCount/"+quizType);
  }



}
