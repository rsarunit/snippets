import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {DashboardComponent} from './dashboard/dashboard.component';
import {PageNotFoundComponent}from './page-not-found/page-not-found.component';
import {LoginComponent} from './login/login.component';
import {QuizFormComponent} from './quiz-form/quiz-form.component';
import {ScoreCardComponent} from './score-card/score-card.component';
import {AuthGuard} from './auth.guard';
const appRoutes: Routes = [
    {
      path: 'dashboard',
      component: DashboardComponent,canActivate:[AuthGuard]
    },{
      path:'login',
      component: LoginComponent,
    },{
      path:'score_card',
      component:ScoreCardComponent
    },
    { path: 'quiz/:id', component: QuizFormComponent,canActivate:[AuthGuard] },
    { path: '',   redirectTo: '/login', pathMatch: 'full' },
    { path: '**', component: PageNotFoundComponent }
  ];
@NgModule({
    imports: [
      RouterModule.forRoot(appRoutes,{useHash: true},)
    ],
    exports: [
      RouterModule
    ],
    providers: [
     
    ]
  })
  export class AppRoutingModule { }
  
  