import { BrowserModule } from '@angular/platform-browser';
import {HttpClientModule} from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { Router } from '@angular/router';
import {AuthGuard} from './auth.guard';
import{AppRoutingModule} from './app-routing.module'
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { NavbarHeaderComponent } from './navbar-header/navbar-header.component';
import { QuizFormComponent } from './quiz-form/quiz-form.component';

import {RestService} from './rest.service';
import { ScoreCardComponent } from './score-card/score-card.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    PageNotFoundComponent,
    NavbarHeaderComponent,
    QuizFormComponent,
    ScoreCardComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    AppRoutingModule
  ],
  providers: [AuthGuard,RestService],
  bootstrap: [AppComponent]
})
export class AppModule { 
}
