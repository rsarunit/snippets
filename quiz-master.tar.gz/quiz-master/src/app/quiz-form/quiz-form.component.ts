import { Component, OnInit,OnDestroy,ViewChild,ElementRef } from '@angular/core';
import {Router,ActivatedRoute} from '@angular/router';
import {NgForm} from '@angular/forms';
import {RestService} from '../rest.service';
import {Question} from '../classes/question';
import {AnswerForm} from '../classes/answer-form';
import {Answer} from '../classes/answer';
@Component({
  selector: 'app-quiz-form',
  templateUrl: './quiz-form.component.html',
  styleUrls: ['./quiz-form.component.css']
})
export class QuizFormComponent implements OnInit,OnDestroy {

  id:string;
  sub:any;

  questions:Question[]=[];

  answer0:string;
  answer1:string;
  answer2:string;
  answer3:string;
  answer4:string;
  answer5:string;
  answer6:string;
  answer7:string;
  answer8:string;
  answer9:string;

  quizAnswers:any=[];
 
  @ViewChild('quiz') public quizForm: NgForm;

  @ViewChild('modalBtn') modalBtn: ElementRef;
  
  score:number;
  displayname:string;
  quizType:string;

  modalTitle:string;
  modalMessage:string;
  redirectFlag:boolean=false;


  constructor(private router:Router,private route:ActivatedRoute,private restService:RestService) { }

  ngOnInit() {
    this.sub=this.route.params.subscribe(params=>{
      this.id=params['id'];
    });
    if(this.id){
    this.restService.getQuizFormData(this.id).subscribe(res=>{
      this.questions=res;
      console.log(JSON.stringify(this.questions));
    });
  }
  }


  ngOnDestroy(){
    this.sub.unsubscribe();
  }

  validateAnswers(){
    console.log(JSON.stringify(this.quizForm.value));
    let answerForm=new AnswerForm();

    if(this.quizAnswers.length!=10){
      this.modalTitle="";
      this.displayname=localStorage.getItem('username');
      this.modalTitle="Hi "+this.displayname;
      this.redirectFlag=false;
      this.modalMessage="Please answer all quiz questions";
      let el: HTMLElement = this.modalBtn.nativeElement as HTMLElement;
      el.click();
      return;
    }

    answerForm.answers=this.quizAnswers;
    answerForm.quizType=this.id;
    answerForm.username=localStorage.getItem('username');
    this.restService.validateAnswer(answerForm).subscribe(res=>{
     // alert(JSON.stringify(res));
      this.score=res.score;
      this.displayname=res.username;
      this.quizType=res.quizType;
      this.modalTitle="";
      this.modalTitle="Congratulations "+this.displayname;
      this.modalMessage="";
      this.modalMessage="Your "+this.quizType+" Quiz Score is "+this.score;
      this.redirectFlag=true;
      let el: HTMLElement = this.modalBtn.nativeElement as HTMLElement;
      el.click();
    //  setTimeout(()=>{
      //  this.router.navigate(['dashboard']);
      //},5000);
    },err=>{});
  }

  reset(){
  this.quizForm.reset();
  this.quizAnswers=[];
  }

  pushAnswer(qid:string,answer:string){
   let answerObj:any={};
   answerObj.answer=answer;
   answerObj.qid=qid;
   this.deleteAnswer(answerObj);
   this.quizAnswers.push(answerObj);
   console.log("Printing answer sheet"+JSON.stringify(this.quizAnswers));
  }

  deleteAnswer(answerObj:Answer) {
   for(var i=0;i<this.quizAnswers.length;i++){
   if(this.quizAnswers[i].qid==answerObj.qid){
     this.quizAnswers.splice(this.quizAnswers.indexOf(this.quizAnswers[i]), 1); 
   }

   }
   
          
}

fireModal(){
  console.log("fireModelCalled");
}

redirect(){
  if(this.redirectFlag){
  this.router.navigate(['dashboard']);
  }
}


}
