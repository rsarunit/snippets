import { Component, OnInit } from '@angular/core';
import {RestService} from '../rest.service';
@Component({
  selector: 'header',
  templateUrl: './navbar-header.component.html',
  styleUrls: ['./navbar-header.component.css']
})
export class NavbarHeaderComponent implements OnInit {

  constructor(private rest:RestService) { }

  playerName:string;

  ngOnInit() {
   this.rest.getPlayerName().subscribe(res=>{
    this.playerName= res;
   });
  }

  logout(){
    localStorage.removeItem('username');
  }



}
