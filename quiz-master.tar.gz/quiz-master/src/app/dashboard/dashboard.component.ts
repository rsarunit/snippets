import { Component, OnInit } from '@angular/core';
import {RestService} from '../rest.service';
@Component({
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor(private restService:RestService) { }

  test:any;

  quizTypeOne:number;
  quizTypeTwo:number;
  quizTypeThree:number;
  
  ngOnInit() {
   
    this.loadQuizStats();
  }

  loadQuizCount(Qtype:string,quizVariable:number){
   
  }

  loadQuizStats(){

    this.restService.getQuizPlayedCount("OOPS").subscribe(
      res=>this.quizTypeOne=res.score
    );
    this.restService.getQuizPlayedCount("Database").subscribe(
      res=>this.quizTypeTwo=res.score
    );
    this.restService.getQuizPlayedCount("Computer").subscribe(
      res=>this.quizTypeThree=res.score
    );
  }


}
